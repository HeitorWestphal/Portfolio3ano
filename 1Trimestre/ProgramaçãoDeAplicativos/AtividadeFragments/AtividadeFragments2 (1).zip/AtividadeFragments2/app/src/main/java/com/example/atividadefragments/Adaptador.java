package com.example.atividadefragments;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.atividadefragments.calculadoraHoras;
import com.example.atividadefragments.camera;
import com.example.atividadefragments.jogoNumeros;

public class Adaptador extends FragmentStateAdapter {
    public Adaptador(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 1:
                return new camera();
            case 2:
                return new jogoNumeros();
        }
        return new calculadoraHoras();
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}