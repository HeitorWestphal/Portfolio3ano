package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText entrada;
    TextView saida;
    int numeroGerado = 0;
    int tentativas = 0;
    Random gerador = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        entrada = findViewById(R.id.entrada);
        saida = findViewById(R.id.textViewSaida);
    }
        public void gerar (View v) {
            tentativas = 0;
            numeroGerado = gerador.nextInt(100) + 1;
            saida.setText("Novo número gerado");
            entrada.setText("");
        }
    public void confirmar (View v){
        tentativas ++;
        int digito = Integer.parseInt(entrada.getText().toString());
        if(digito > numeroGerado){
            saida.setText("O número gerado é menor");
        }
        else if(digito < numeroGerado){
            saida.setText("O número gerado é maior");
        }
        else{
            saida.setText("Parabéns, você acertou em " + tentativas + " tentativas!");
        }
    }
}